package org.demotest;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private ListView listView;
	private List<DemoClass> lt;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		listView = (ListView) this.findViewById(R.id.listView1);
		lt = new ArrayList<DemoClass>();
		DemoClass d = new DemoClass();
		d.time = "18:06";
		d.type = 1;
		d.content = "OpenGL����ѧϰ";
		lt.add(d);
		DemoClass d2 = new DemoClass();
		d2.time = "18:09";
		d2.type = 2;
		d2.content = "���ݽṹ";
		lt.add(d2);
		DemoClass d21 = new DemoClass();
		d21.time = "����";
		d21.type = 5;
		d21.content = "";
		List<Integer> imgLt = new ArrayList<Integer>();
		imgLt.add(R.drawable.hawana_0);
		imgLt.add(R.drawable.xuanfenghei_3);
		imgLt.add(R.drawable.xuanfenghei_10);
		d21.imageLt = imgLt;
		lt.add(d21);

		DemoClass d3 = new DemoClass();
		d3.time = "09-13";
		d3.type = 3;
		d3.content = "�Ż��㷨";
		lt.add(d3);
		listView.setAdapter(new MyAdapter());
	}

	class MyAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return lt.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return lt.get(arg0);
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			if (arg1 == null) {
				arg1 = View.inflate(MainActivity.this, R.layout.item, null);
			}
			final TextView timeView = (TextView) arg1
					.findViewById(R.id.textView1);
			final ImageView imageView = (ImageView) arg1
					.findViewById(R.id.imageView1);
			final TextView contentView = (TextView) arg1
					.findViewById(R.id.textView2);
			final TextView typeView = (TextView) arg1
					.findViewById(R.id.textView3);
			final LinearLayout ll = (LinearLayout) arg1
					.findViewById(R.id.linearLayout1);
			final FrameLayout fl = (FrameLayout) arg1
					.findViewById(R.id.frameLayout2);

			timeView.setText(lt.get(arg0).time);

			switch (lt.get(arg0).type) {
			case 1: {
				typeView.setText("������");
				setContentView(ll,fl,contentView,arg0);
				break;
			}
			case 2: {
				typeView.setText("������");
				setContentView(ll,fl,contentView,arg0);
				break;
			}
			case 3: {
				typeView.setText("�����");
				setContentView(ll,fl,contentView,arg0);
				break;
			}
			case 5: {
				ll.setVisibility(View.GONE);
				fl.setVisibility(View.VISIBLE);
				final Gallery gallery = (Gallery) arg1
						.findViewById(R.id.galler1);
				gallery.setAdapter(new ImageAdapter(lt.get(arg0).imageLt));
				final TextView textViewK = (TextView) arg1
						.findViewById(R.id.textViewk);
				textViewK.setText("�ϴ���" + lt.get(arg0).imageLt.size()
						+ "����Ƭ �� �ҵ����");
				break;
			}
			}

			return arg1;
		}
		
		public void setContentView(LinearLayout ll ,FrameLayout fl,TextView contentView,int arg0){
			ll.setVisibility(View.VISIBLE);
			fl.setVisibility(View.GONE);
			contentView.setText(lt.get(arg0).content);
			contentView.setTag(arg0);
			contentView.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View arg0) {
					Toast.makeText(
							MainActivity.this,
							lt.get(Integer.parseInt(arg0.getTag()
									.toString())).content, 3000).show();
				}
			});
		}
		
		
	}

	class ImageAdapter extends BaseAdapter {
		private List<Integer> lt;

		public ImageAdapter(List<Integer> lt) {
			super();
			this.lt = lt;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return lt.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return lt.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView = new ImageView(MainActivity.this);
			imageView.setImageResource(lt.get(position));
			imageView.setAdjustViewBounds(true);
			imageView.setLayoutParams(new Gallery.LayoutParams(150, 130));
			imageView.setScaleType(ScaleType.FIT_XY);
			return imageView;
		}

	}

	class DemoClass {
		String time;
		int type;
		String content;
		List<Integer> imageLt;
	}
}