var oss__initiate__multipart__upload__request_8h =
[
    [ "_OSS_OBJECT_METADATA_H", "db/d9d/oss__initiate__multipart__upload__request_8h.html#a72a0a141e87e531876bcacee82bfa8de", null ],
    [ "oss_initiate_multipart_upload_request_t", "db/dd9/group__oss__initiate__multipart__upload__request__t.html#ga71c6a356bdc280814caf5c7b2be643a7", null ],
    [ "initiate_multipart_upload_request_finalize", "db/dd9/group__oss__initiate__multipart__upload__request__t.html#gaea9fe122f01955eefdbb428cf316435c", null ],
    [ "initiate_multipart_upload_request_initialize", "db/dd9/group__oss__initiate__multipart__upload__request__t.html#gaf10fdb2081ea115ad10dc82fce73a8ec", null ],
    [ "initiate_multipart_upload_request_initialize_with_metadata", "db/dd9/group__oss__initiate__multipart__upload__request__t.html#gae21dd6a0e7e923a74e7c34cf916df22d", null ]
];