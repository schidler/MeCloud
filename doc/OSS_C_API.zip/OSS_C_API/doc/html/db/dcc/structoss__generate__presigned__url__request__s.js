var structoss__generate__presigned__url__request__s =
[
    [ "add_user_metadata", "db/dcc/structoss__generate__presigned__url__request__s.html#aa52f1f23dba5d70a534f586a886db167", null ],
    [ "bucket_name", "db/dcc/structoss__generate__presigned__url__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "expiration", "db/dcc/structoss__generate__presigned__url__request__s.html#a2ed6edb4b58219b5182b274494bcd8b2", null ],
    [ "get_bucket_name", "db/dcc/structoss__generate__presigned__url__request__s.html#a1ec1775c70b0b1353a9f3477a107a82d", null ],
    [ "get_expiration", "db/dcc/structoss__generate__presigned__url__request__s.html#a7bdd182209c9ddaa191bd4b0695c1094", null ],
    [ "get_key", "db/dcc/structoss__generate__presigned__url__request__s.html#a0d3537daab7a402c2113cd94010c2b48", null ],
    [ "get_method", "db/dcc/structoss__generate__presigned__url__request__s.html#a046b58eabd9630dc95e75129c8bb6368", null ],
    [ "get_response_headers", "db/dcc/structoss__generate__presigned__url__request__s.html#a840126f6d6000676712373e65f34b7d9", null ],
    [ "get_user_metadata", "db/dcc/structoss__generate__presigned__url__request__s.html#a2b99019c7af39bab65a655007f22af74", null ],
    [ "key", "db/dcc/structoss__generate__presigned__url__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "method", "db/dcc/structoss__generate__presigned__url__request__s.html#aca2544ecce27ac7a7e973d466c3a8fd4", null ],
    [ "response_headers", "db/dcc/structoss__generate__presigned__url__request__s.html#a5d18d12e36422948f262b064ea36d69b", null ],
    [ "set_bucket_name", "db/dcc/structoss__generate__presigned__url__request__s.html#a9f8a9260f5f9afb3de35e8774d1c9d0f", null ],
    [ "set_expiration", "db/dcc/structoss__generate__presigned__url__request__s.html#a35d672efb7404b719e5a45ac9d371d73", null ],
    [ "set_key", "db/dcc/structoss__generate__presigned__url__request__s.html#a358e8c98d7773a69dae21ab9cc8a2bda", null ],
    [ "set_method", "db/dcc/structoss__generate__presigned__url__request__s.html#a12ff740dd40f776fd5d73e6a95d84ada", null ],
    [ "set_response_headers", "db/dcc/structoss__generate__presigned__url__request__s.html#a340831357350c70d12d083c93dcc0257", null ],
    [ "set_user_metadata", "db/dcc/structoss__generate__presigned__url__request__s.html#a72cef94e30fc363331ffc174d0da2ae1", null ],
    [ "user_metadata", "db/dcc/structoss__generate__presigned__url__request__s.html#ab48b022cea1a4ad827306c5e1826d3c2", null ]
];