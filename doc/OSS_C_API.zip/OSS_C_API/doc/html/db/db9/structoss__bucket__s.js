var structoss__bucket__s =
[
    [ "create_date", "db/db9/structoss__bucket__s.html#a4660bca8e5ecbe2fe2f6fdad153c4c01", null ],
    [ "get_create_date", "db/db9/structoss__bucket__s.html#a36a27c8982915327b3f2511b8f776be2", null ],
    [ "get_name", "db/db9/structoss__bucket__s.html#adaccd9e5dcd9d03330a19a3a2cafdbcd", null ],
    [ "get_owner", "db/db9/structoss__bucket__s.html#afd091299a7dc81b9c76e933792da585f", null ],
    [ "name", "db/db9/structoss__bucket__s.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "owner", "db/db9/structoss__bucket__s.html#a389504832e4d361979100f9267479b8a", null ],
    [ "set_create_date", "db/db9/structoss__bucket__s.html#aab93bd5ed0f03acd55f45b322bf2f0a0", null ],
    [ "set_name", "db/db9/structoss__bucket__s.html#acb2608f931a8981b9374100f4248fd56", null ],
    [ "set_owner", "db/db9/structoss__bucket__s.html#a3910a919c0b18db622f93aaa293156bc", null ]
];