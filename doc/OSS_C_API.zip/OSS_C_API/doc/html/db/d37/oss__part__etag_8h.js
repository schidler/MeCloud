var oss__part__etag_8h =
[
    [ "oss_part_etag_t", "db/d87/group__oss__part__etag__t.html#gaec6489355e7f6bf055044d7df6b53bfd", null ],
    [ "part_etag_finalize", "db/d87/group__oss__part__etag__t.html#ga69cd1d8bf8fd5dcff58f7c38e563dd48", null ],
    [ "part_etag_initialize", "db/d87/group__oss__part__etag__t.html#gabafc502992f1b00a25cb78de403056ff", null ]
];