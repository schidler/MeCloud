var structoss__grant__s =
[
    [ "get_identifier", "db/d19/structoss__grant__s.html#affaf15679e6d228314560ecb3dd4525c", null ],
    [ "get_permission", "db/d19/structoss__grant__s.html#a661614e992101d6503e538a5a2709e70", null ],
    [ "identifier", "db/d19/structoss__grant__s.html#af5351a0143adaf16c64b881aee01d893", null ],
    [ "next", "db/d19/structoss__grant__s.html#a59aafbccab53b49e8f1f99f0eb8ff0a1", null ],
    [ "permission", "db/d19/structoss__grant__s.html#a5b0696639232e0d0c5ab70c467f0e6e2", null ],
    [ "set_identifier", "db/d19/structoss__grant__s.html#af9faa8f526aaf9821e719e08e76ef386", null ],
    [ "set_permission", "db/d19/structoss__grant__s.html#aea398169ea67b224353bb00aea093b4b", null ]
];