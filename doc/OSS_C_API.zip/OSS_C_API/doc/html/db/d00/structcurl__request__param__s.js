var structcurl__request__param__s =
[
    [ "header_buffer", "db/d00/structcurl__request__param__s.html#a1719e0ec2247af9fe6b5d09dad20ae3f", null ],
    [ "recv_buffer", "db/d00/structcurl__request__param__s.html#aad5dd320d7f482117198cbebd4172161", null ],
    [ "send_buffer", "db/d00/structcurl__request__param__s.html#a1a69ab56a701418ab38dee93f28fbaf8", null ]
];