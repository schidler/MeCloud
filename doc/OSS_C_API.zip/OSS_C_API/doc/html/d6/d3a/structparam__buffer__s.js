var structparam__buffer__s =
[
    [ "allocated", "d6/d3a/structparam__buffer__s.html#a44ac4c6a3693f3d2fa34a50428e42237", null ],
    [ "code", "d6/d3a/structparam__buffer__s.html#ad5035e9ddbe5118f0f35c4db612d13c2", null ],
    [ "fp", "d6/d3a/structparam__buffer__s.html#aa065f30aa9f5f9a42132c82c787ee70b", null ],
    [ "left", "d6/d3a/structparam__buffer__s.html#a05374b750b0fc472c34ee61e6f028bba", null ],
    [ "ptr", "d6/d3a/structparam__buffer__s.html#a935adc2e417a61d7eb6f04efb18ba031", null ]
];