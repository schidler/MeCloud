var structoss__complete__multipart__upload__result__s =
[
    [ "bucket_name", "d6/d69/structoss__complete__multipart__upload__result__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "etag", "d6/d69/structoss__complete__multipart__upload__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_bucket_name", "d6/d69/structoss__complete__multipart__upload__result__s.html#a952631a38339944f48855d74de4968fb", null ],
    [ "get_etag", "d6/d69/structoss__complete__multipart__upload__result__s.html#a05d784a048172876a45e0bdcf9f6517c", null ],
    [ "get_key", "d6/d69/structoss__complete__multipart__upload__result__s.html#a6d6c64c8a6e23f3a635f5c0dc741ae94", null ],
    [ "get_location", "d6/d69/structoss__complete__multipart__upload__result__s.html#a4124b585eb5722d6f9304103a7ba644a", null ],
    [ "key", "d6/d69/structoss__complete__multipart__upload__result__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "location", "d6/d69/structoss__complete__multipart__upload__result__s.html#a6a0d5603410d5eda93c0ff341966cce1", null ],
    [ "set_bucket_name", "d6/d69/structoss__complete__multipart__upload__result__s.html#aeab9716225cf71a4c7b72a33048a5bf0", null ],
    [ "set_etag", "d6/d69/structoss__complete__multipart__upload__result__s.html#a098ef27f52a336314afbfd99fe3d9ae1", null ],
    [ "set_key", "d6/d69/structoss__complete__multipart__upload__result__s.html#ae57dec38cf3c4d90587846ee46a7cc70", null ],
    [ "set_location", "d6/d69/structoss__complete__multipart__upload__result__s.html#af7bd46a61fc479af90f8770e8a7a8fcf", null ]
];