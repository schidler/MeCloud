var oss__copy__object__request_8h =
[
    [ "_OSS_OBJECT_METADATA_H", "d6/dce/oss__copy__object__request_8h.html#a72a0a141e87e531876bcacee82bfa8de", null ],
    [ "oss_copy_object_request_t", "df/ddb/group__oss__copy__object__request__t.html#ga3432498f6e94439a511218a972182e9e", null ],
    [ "copy_object_request_finalize", "df/ddb/group__oss__copy__object__request__t.html#ga36c1803ba6b6c6796d948048925b6626", null ],
    [ "copy_object_request_initialize", "df/ddb/group__oss__copy__object__request__t.html#gae9e3285a0be6afef896e2ceed7620136", null ]
];