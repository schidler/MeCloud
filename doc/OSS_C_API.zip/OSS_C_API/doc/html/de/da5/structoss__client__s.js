var structoss__client__s =
[
    [ "access_id", "de/da5/structoss__client__s.html#a33c6d88cd03f42ab258dc2da344409b2", null ],
    [ "access_key", "de/da5/structoss__client__s.html#ad6f7717505e9a68b5f55d3bed7105898", null ],
    [ "endpoint", "de/da5/structoss__client__s.html#a6d2d1c31529bee906473fcabaffff34f", null ]
];