var structoss__post__object__group__result__s =
[
    [ "bucket_name", "de/d68/structoss__post__object__group__result__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "etag", "de/d68/structoss__post__object__group__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_bucket_name", "de/d68/structoss__post__object__group__result__s.html#aa9f843deba55a7ffe55f702293d41202", null ],
    [ "get_etag", "de/d68/structoss__post__object__group__result__s.html#a2a1341e772084be6aad15c2207b2c12c", null ],
    [ "get_key", "de/d68/structoss__post__object__group__result__s.html#a9ce8439969de1276077cd7defd4e2bd7", null ],
    [ "get_size", "de/d68/structoss__post__object__group__result__s.html#ae57710857694b4658908b58ac395c9b5", null ],
    [ "key", "de/d68/structoss__post__object__group__result__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "set_bucket_name", "de/d68/structoss__post__object__group__result__s.html#ac28da9878070b3b453e0c7758b328c5f", null ],
    [ "set_etag", "de/d68/structoss__post__object__group__result__s.html#a04714abe91bc12eb2595b236f55e77de", null ],
    [ "set_key", "de/d68/structoss__post__object__group__result__s.html#abda286cb6818af5ed69812ebd7ef64b1", null ],
    [ "set_size", "de/d68/structoss__post__object__group__result__s.html#aea0df965b627c111ffc3ac25bd3d6a07", null ],
    [ "size", "de/d68/structoss__post__object__group__result__s.html#aac913b3a1f6ef005d66bf7a84428773e", null ]
];