var structoss__put__object__result__s =
[
    [ "etag", "de/d52/structoss__put__object__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "de/d52/structoss__put__object__result__s.html#aff827dfadd59692b74205aafadcacc74", null ],
    [ "set_etag", "de/d52/structoss__put__object__result__s.html#a40cb94d429d252c0c622c9c8b1052d3e", null ]
];