var structoss__part__summary__s =
[
    [ "etag", "de/dc7/structoss__part__summary__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "de/dc7/structoss__part__summary__s.html#a0a5b4cc229d2fee171e4028d7de98310", null ],
    [ "get_last_modified", "de/dc7/structoss__part__summary__s.html#ab73e876cab97d6b47ce0ab9d83103683", null ],
    [ "get_part_number", "de/dc7/structoss__part__summary__s.html#a798a2826c9b58621efd29ec1163cd997", null ],
    [ "get_size", "de/dc7/structoss__part__summary__s.html#af51aaecdf66756a16bd91e8a49141527", null ],
    [ "last_modified", "de/dc7/structoss__part__summary__s.html#a99d1353a783d112bf698109c33c15e7a", null ],
    [ "part_number", "de/dc7/structoss__part__summary__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "set_etag", "de/dc7/structoss__part__summary__s.html#a5cdcf2c689123688badddb29f7dfeb04", null ],
    [ "set_last_modified", "de/dc7/structoss__part__summary__s.html#a6811743b256d64ea2c8ea43e579d559a", null ],
    [ "set_part_number", "de/dc7/structoss__part__summary__s.html#a8f335facafe96f8b4edc6fb901aad2dd", null ],
    [ "set_size", "de/dc7/structoss__part__summary__s.html#a89d78fda2865227c61c68b9f809a5205", null ],
    [ "size", "de/dc7/structoss__part__summary__s.html#a37363161b41c4165b98cba7abc7a9d95", null ]
];