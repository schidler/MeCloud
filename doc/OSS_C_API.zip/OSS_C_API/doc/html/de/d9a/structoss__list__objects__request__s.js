var structoss__list__objects__request__s =
[
    [ "bucket_name", "de/d9a/structoss__list__objects__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "delimiter", "de/d9a/structoss__list__objects__request__s.html#aac0782d159773b2ffc74276d33b81d3c", null ],
    [ "get_bucket_name", "de/d9a/structoss__list__objects__request__s.html#a77bc515d24fb58ac783ff12c4a7d02c6", null ],
    [ "get_delimiter", "de/d9a/structoss__list__objects__request__s.html#ad6e233fecd5df38b8c11a27d7cfab868", null ],
    [ "get_marker", "de/d9a/structoss__list__objects__request__s.html#a5976772e9da75ee652c79e095c9665ac", null ],
    [ "get_max_keys", "de/d9a/structoss__list__objects__request__s.html#a0b9e20570cdf0afb2ec350abc6c97ee1", null ],
    [ "get_prefix", "de/d9a/structoss__list__objects__request__s.html#acd6c917f30b7afd0b3857fe09d557db3", null ],
    [ "marker", "de/d9a/structoss__list__objects__request__s.html#aee481970ba654213bf28035c508259bc", null ],
    [ "max_keys", "de/d9a/structoss__list__objects__request__s.html#a5f8f0fddb67b172ff8fd84300a048a15", null ],
    [ "prefix", "de/d9a/structoss__list__objects__request__s.html#ad2849cf781a4db22cc1b31eaaee50a4f", null ],
    [ "set_bucket_name", "de/d9a/structoss__list__objects__request__s.html#aa361f541385bd7b158debae09366983f", null ],
    [ "set_delimiter", "de/d9a/structoss__list__objects__request__s.html#a2d25d2198bedfdfa2eb5b2478bfeb176", null ],
    [ "set_marker", "de/d9a/structoss__list__objects__request__s.html#abc5ac54e8011d7e6c6f2e5915a98fb48", null ],
    [ "set_max_keys", "de/d9a/structoss__list__objects__request__s.html#a4755cae0ced1ed8a96513a7bd34abf99", null ],
    [ "set_prefix", "de/d9a/structoss__list__objects__request__s.html#a141f28bbf452ca828272e6304b330124", null ]
];