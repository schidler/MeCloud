var structoss__multipart__upload__s =
[
    [ "get_initiated", "de/dc5/structoss__multipart__upload__s.html#a16e597d343ccc948ec9e5c626040fccb", null ],
    [ "get_key", "de/dc5/structoss__multipart__upload__s.html#afef87d8254d095a4b9ecefcf5f442dac", null ],
    [ "get_storage_class", "de/dc5/structoss__multipart__upload__s.html#a7be5c1fc6eecf28fb7803a40ad3912a4", null ],
    [ "get_upload_id", "de/dc5/structoss__multipart__upload__s.html#a0d06709d71b7654095219638211c894f", null ],
    [ "initiated", "de/dc5/structoss__multipart__upload__s.html#a4f335d47ef922588400ccc852320f935", null ],
    [ "key", "de/dc5/structoss__multipart__upload__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "set_initiated", "de/dc5/structoss__multipart__upload__s.html#a36c8bbb8e5574e67b3ac4b1b8551230a", null ],
    [ "set_key", "de/dc5/structoss__multipart__upload__s.html#a86549aa8901c466f8093a06a9ec75eaa", null ],
    [ "set_storage_class", "de/dc5/structoss__multipart__upload__s.html#ae74db0568e38458d0d0649076d5abd56", null ],
    [ "set_upload_id", "de/dc5/structoss__multipart__upload__s.html#af1bf7c56d1c883c1c8abbf925da6e014", null ],
    [ "storage_class", "de/dc5/structoss__multipart__upload__s.html#afad849df9a7cfeba4abd9e511683a2ff", null ],
    [ "upload_id", "de/dc5/structoss__multipart__upload__s.html#a5755e07d2244386fcb4c521cfb09eed6", null ]
];