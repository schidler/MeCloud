var oss__get__object__group__request_8h =
[
    [ "_OSS_RESPONSE_HEADER_OVERRIDES_H", "de/d97/oss__get__object__group__request_8h.html#a4a9f34efd1f78f30e27bca353e893259", null ],
    [ "oss_get_object_group_request_t", "d8/d13/group__oss__get__object__group__request__t.html#ga15c4ef4ce5a1060a70ea7d5edbaebf3e", null ],
    [ "get_object_group_request_finalize", "d8/d13/group__oss__get__object__group__request__t.html#gae85d93447cb99de9ba4147030272398a", null ],
    [ "get_object_group_request_initialize", "d8/d13/group__oss__get__object__group__request__t.html#ga0d7355f383f49573d06303d102851b2e", null ]
];