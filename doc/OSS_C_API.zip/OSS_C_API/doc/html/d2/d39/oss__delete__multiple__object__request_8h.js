var oss__delete__multiple__object__request_8h =
[
    [ "oss_delete_multiple_object_request_t", "d3/d7a/group__oss__delete__multiple__object__request__t.html#ga0a5b07cc5a38f31968acc228d0e4cb4c", null ],
    [ "delete_multiple_object_request_finalize", "d3/d7a/group__oss__delete__multiple__object__request__t.html#ga0f40dbcb23f52e7c6f29457fdd005d35", null ],
    [ "delete_multiple_object_request_initialize", "d3/d7a/group__oss__delete__multiple__object__request__t.html#gaf8c4e3b6fca951c65f5dc608740fbdcc", null ]
];