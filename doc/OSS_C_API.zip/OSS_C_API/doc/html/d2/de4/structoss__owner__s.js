var structoss__owner__s =
[
    [ "display_name", "d2/de4/structoss__owner__s.html#a4b3dc854913a2dc6d39a8f54f82a01da", null ],
    [ "get_display_name", "d2/de4/structoss__owner__s.html#a99c7149bf682e1d865b8d9d3578dc73f", null ],
    [ "get_id", "d2/de4/structoss__owner__s.html#a350cd905df8a66767cb7be86f84ab6d4", null ],
    [ "id", "d2/de4/structoss__owner__s.html#aecb3b0d045ada529257a2fbf8f829599", null ],
    [ "set_display_name", "d2/de4/structoss__owner__s.html#a00f6bcac4c8d6e54650a6339d383b567", null ],
    [ "set_id", "d2/de4/structoss__owner__s.html#a822fb38e00696ba6789fdf0245e00267", null ]
];