var structoss__upload__part__result__s =
[
    [ "etag", "d2/de4/structoss__upload__part__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "d2/de4/structoss__upload__part__result__s.html#a876000f6027a496a4a9e4e34429c4361", null ],
    [ "get_part_etag", "d2/de4/structoss__upload__part__result__s.html#ad1d8b29a4e521ea98c9ec79f3c2641e7", null ],
    [ "get_part_number", "d2/de4/structoss__upload__part__result__s.html#a0bc10db6841c4581e962d846d32c42e0", null ],
    [ "part_number", "d2/de4/structoss__upload__part__result__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "set_etag", "d2/de4/structoss__upload__part__result__s.html#a1bdbe14fa5e61ef9f30183cbcd437725", null ],
    [ "set_part_number", "d2/de4/structoss__upload__part__result__s.html#ab52714be4f34bf10804057cd02136e4c", null ]
];