var oss__upload__part__result_8h =
[
    [ "_OSS_PART_ETAG_H", "d2/d10/oss__upload__part__result_8h.html#ab2580b8c78bff3bf12c9fed1126b0418", null ],
    [ "oss_upload_part_result_t", "d1/dc8/group__oss__upload__part__result__t.html#gad1454e9e93240f293552cc79782e84f5", null ],
    [ "upload_part_result_finalize", "d1/dc8/group__oss__upload__part__result__t.html#ga49c9386797edcac343f44b3552f2793e", null ],
    [ "upload_part_result_initialize", "d1/dc8/group__oss__upload__part__result__t.html#gaddb5efde2f62c9299005b78aa69392b5", null ]
];