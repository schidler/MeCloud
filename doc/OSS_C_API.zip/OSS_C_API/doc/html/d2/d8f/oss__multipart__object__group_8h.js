var oss__multipart__object__group_8h =
[
    [ "oss_multipart_object_group_t", "d6/d9e/group__oss__multipart__object__group__t.html#ga467315eac0b4803909332692b5cf8d8c", null ],
    [ "multipart_object_group_finalize", "d6/d9e/group__oss__multipart__object__group__t.html#ga4d9bf6e7ac626f56f46c4d85dba31d37", null ],
    [ "multipart_object_group_initialize", "d6/d9e/group__oss__multipart__object__group__t.html#gadfd69cdbfcdd2ac3216423881440e2bc", null ]
];