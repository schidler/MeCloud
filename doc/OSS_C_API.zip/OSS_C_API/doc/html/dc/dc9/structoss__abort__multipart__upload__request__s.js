var structoss__abort__multipart__upload__request__s =
[
    [ "bucket_name", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "dc/dc9/structoss__abort__multipart__upload__request__s.html#ac53c5bd10d86f2b68d560fdac97fdad2", null ],
    [ "get_key", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a617fa4f72a9aa9dedc7a70e22ed6668c", null ],
    [ "get_upload_id", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a905e50eca99ac1fa62feb6537d56d33d", null ],
    [ "key", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "set_bucket_name", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a069f345c0319aff80b6da05369c1b8ff", null ],
    [ "set_key", "dc/dc9/structoss__abort__multipart__upload__request__s.html#ab2582b1866a9901a5bd9e5738ba22973", null ],
    [ "set_upload_id", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a3ae400a08cbb4e52105faa9eb7672420", null ],
    [ "upload_id", "dc/dc9/structoss__abort__multipart__upload__request__s.html#a5755e07d2244386fcb4c521cfb09eed6", null ]
];