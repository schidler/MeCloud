var structoss__response__header__overrides__s =
[
    [ "cache_control", "dc/d86/structoss__response__header__overrides__s.html#a199c39c56be62134d72fba0c42648944", null ],
    [ "content_disposition", "dc/d86/structoss__response__header__overrides__s.html#a3bcfaf6d358f5c75f51855da3a287cc9", null ],
    [ "content_encoding", "dc/d86/structoss__response__header__overrides__s.html#a31047d42330e6861f2d46aaf96ccb0d6", null ],
    [ "content_language", "dc/d86/structoss__response__header__overrides__s.html#a7efc8ca35510c6d59b850d2cace1b636", null ],
    [ "content_type", "dc/d86/structoss__response__header__overrides__s.html#a7b9c7814d28acb614167ccd41c80f504", null ],
    [ "expires", "dc/d86/structoss__response__header__overrides__s.html#adb985222d6fc3d8bfb737c259d138366", null ],
    [ "get_cache_control", "dc/d86/structoss__response__header__overrides__s.html#a525923cb1c8e33b754c387cdeadb1824", null ],
    [ "get_content_disposition", "dc/d86/structoss__response__header__overrides__s.html#aff08df7a5e721975a70b9b7576378c45", null ],
    [ "get_content_encoding", "dc/d86/structoss__response__header__overrides__s.html#a1404caf52d642c0e0cfb74f38395bf9d", null ],
    [ "get_content_language", "dc/d86/structoss__response__header__overrides__s.html#a0e553fecdbdea911d567f80b824c36bf", null ],
    [ "get_content_type", "dc/d86/structoss__response__header__overrides__s.html#a3be1193376d68144748e34a654c941d6", null ],
    [ "get_expires", "dc/d86/structoss__response__header__overrides__s.html#a1d9c7019b37ed84f61ac6bf8f31ae39d", null ],
    [ "set_cache_control", "dc/d86/structoss__response__header__overrides__s.html#aa11cf51b77df7afc28ccbc97f3ecdc0a", null ],
    [ "set_content_disposition", "dc/d86/structoss__response__header__overrides__s.html#ad364752b9f1baa0c2d86aebe0de27fa5", null ],
    [ "set_content_encoding", "dc/d86/structoss__response__header__overrides__s.html#a7d6d5273f393ae7802d9ac903149eddc", null ],
    [ "set_content_language", "dc/d86/structoss__response__header__overrides__s.html#a1e120471f150bc4f4048b13d8094dd58", null ],
    [ "set_content_type", "dc/d86/structoss__response__header__overrides__s.html#a64fc7dce0b7053b31727891112029234", null ],
    [ "set_expires", "dc/d86/structoss__response__header__overrides__s.html#a36c4449b1afdf9daa86010ab9ae5148f", null ]
];