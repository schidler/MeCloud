var oss__post__object__group__result_8h =
[
    [ "oss_post_object_group_result_t", "df/d6d/group__oss__post__object__group__result__t.html#ga077a4de071b1745fab88b0a7225e45a6", null ],
    [ "post_object_group_result_finalize", "df/d6d/group__oss__post__object__group__result__t.html#gad5ce9621c091aa8c0b322c7ca03a4f8f", null ],
    [ "post_object_group_result_initialize", "df/d6d/group__oss__post__object__group__result__t.html#gae418251ec5c65f8e2dd788117654b083", null ]
];