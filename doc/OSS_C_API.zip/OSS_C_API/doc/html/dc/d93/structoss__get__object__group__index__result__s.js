var structoss__get__object__group__index__result__s =
[
    [ "bucket_name", "dc/d93/structoss__get__object__group__index__result__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "etag", "dc/d93/structoss__get__object__group__index__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "file_length", "dc/d93/structoss__get__object__group__index__result__s.html#a58fae7514578a24f7d6e564099b4bf61", null ],
    [ "get_bucket_name", "dc/d93/structoss__get__object__group__index__result__s.html#a32baccdf57451f8fb04177cb1c343445", null ],
    [ "get_etag", "dc/d93/structoss__get__object__group__index__result__s.html#ac846edffa7742f2f09a6f8869879921a", null ],
    [ "get_file_length", "dc/d93/structoss__get__object__group__index__result__s.html#ada3c1b73ab5a3b169c96d9329040825a", null ],
    [ "get_group", "dc/d93/structoss__get__object__group__index__result__s.html#aa82b1620b5c91bfd0a6103f43f94c1a0", null ],
    [ "get_key", "dc/d93/structoss__get__object__group__index__result__s.html#ae18ae26463f5b4f0201508228bded8ea", null ],
    [ "group", "dc/d93/structoss__get__object__group__index__result__s.html#ab6052b1d399aaebd0a1b12dc1e155455", null ],
    [ "key", "dc/d93/structoss__get__object__group__index__result__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "part_number", "dc/d93/structoss__get__object__group__index__result__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "set_bucket_name", "dc/d93/structoss__get__object__group__index__result__s.html#a54ef3f4c618818b9db0de08333061a72", null ],
    [ "set_etag", "dc/d93/structoss__get__object__group__index__result__s.html#a4bf45afaaefd3aa8c4836f3a31338cb2", null ],
    [ "set_file_length", "dc/d93/structoss__get__object__group__index__result__s.html#a142a32b9f5566797b44e933c10fdb555", null ],
    [ "set_group", "dc/d93/structoss__get__object__group__index__result__s.html#acbf93009237a8de8a657cc34cb00f683", null ],
    [ "set_key", "dc/d93/structoss__get__object__group__index__result__s.html#a21168989665c3f8dfbf4a472ed0e93b0", null ]
];