var structoss__object__group__item__s =
[
    [ "etag", "d3/d88/structoss__object__group__item__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "d3/d88/structoss__object__group__item__s.html#af6e736f1f14ca043018b17dea00490a0", null ],
    [ "get_part_name", "d3/d88/structoss__object__group__item__s.html#af4d752cd1ea0db22473ec5f024489c9e", null ],
    [ "get_part_number", "d3/d88/structoss__object__group__item__s.html#ada5fcc9e6d86fc46143aaf6b581b8d7a", null ],
    [ "part_name", "d3/d88/structoss__object__group__item__s.html#a28556c0e804ff9fa3d3e0c8f54489223", null ],
    [ "part_number", "d3/d88/structoss__object__group__item__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "set_etag", "d3/d88/structoss__object__group__item__s.html#a0b26cdaaec8504ad023cdce3411bdfbe", null ],
    [ "set_part_name", "d3/d88/structoss__object__group__item__s.html#a10226177cd014fb970b1b41ee5512944", null ],
    [ "set_part_number", "d3/d88/structoss__object__group__item__s.html#a187e510513de7574d12c05613041b4f8", null ]
];