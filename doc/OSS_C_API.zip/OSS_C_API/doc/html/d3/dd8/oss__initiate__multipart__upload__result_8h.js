var oss__initiate__multipart__upload__result_8h =
[
    [ "oss_initiate_multipart_upload_result_t", "d7/d86/group__oss__initiate__multipart__upload__result__t.html#gafe435675c0a3f02b8945431426b4364c", null ],
    [ "initiate_multipart_upload_result_finalize", "d7/d86/group__oss__initiate__multipart__upload__result__t.html#ga5af07fb294b45f6a9dba50b887177578", null ],
    [ "initiate_multipart_upload_result_initialize", "d7/d86/group__oss__initiate__multipart__upload__result__t.html#ga3f03807444a495d587a95c8c457efabd", null ]
];