var oss__object_8h =
[
    [ "_OSS_OBJECT_METADATA_H", "d4/d24/oss__object_8h.html#a72a0a141e87e531876bcacee82bfa8de", null ],
    [ "oss_object_t", "d2/d21/group__oss__object__t.html#ga5c4da786a37f12b02cbbc23cb5975c90", null ],
    [ "object_finalize", "d2/d21/group__oss__object__t.html#ga208c79adaeceb63853c381aa241ecfa9", null ],
    [ "object_initialize", "d2/d21/group__oss__object__t.html#ga67675080f4651b2ce6481432fecba192", null ]
];