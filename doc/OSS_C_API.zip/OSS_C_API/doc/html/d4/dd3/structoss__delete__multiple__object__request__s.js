var structoss__delete__multiple__object__request__s =
[
    [ "bucket_name", "d4/dd3/structoss__delete__multiple__object__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d4/dd3/structoss__delete__multiple__object__request__s.html#aff8a475b2a20768c4c14fbc4f02690e9", null ],
    [ "get_keys", "d4/dd3/structoss__delete__multiple__object__request__s.html#ac2bd0cccbef05e6f59443844e291fa4f", null ],
    [ "get_mode", "d4/dd3/structoss__delete__multiple__object__request__s.html#a15b11a2f6ea1c23f56465bfdc4210b97", null ],
    [ "keynums", "d4/dd3/structoss__delete__multiple__object__request__s.html#a0cfc321ece3f05442558128ca9d52a1e", null ],
    [ "keys", "d4/dd3/structoss__delete__multiple__object__request__s.html#ae73cb9d66858e2b47df1ba18eb285075", null ],
    [ "mode", "d4/dd3/structoss__delete__multiple__object__request__s.html#a4b81f71be6f86bc436d6e9d87d34592b", null ],
    [ "set_bucket_name", "d4/dd3/structoss__delete__multiple__object__request__s.html#a67aae369544145f9a17055d77f867a0f", null ],
    [ "set_keys", "d4/dd3/structoss__delete__multiple__object__request__s.html#a4f2da8731a169cd927c9ff50e27f3935", null ],
    [ "set_mode", "d4/dd3/structoss__delete__multiple__object__request__s.html#a3ecf9963b237c2ba1670000331887903", null ]
];