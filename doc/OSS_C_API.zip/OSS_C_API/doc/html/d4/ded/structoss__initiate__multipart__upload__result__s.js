var structoss__initiate__multipart__upload__result__s =
[
    [ "bucket_name", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a14e4731813c18a0907d1b4ac81a341cd", null ],
    [ "get_key", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a5e288f456149f58d7559f206a2d1d50f", null ],
    [ "get_upload_id", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a2e4208dc50056c4d640b5e758dd65d21", null ],
    [ "key", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "set_bucket_name", "d4/ded/structoss__initiate__multipart__upload__result__s.html#ab0fb6d145ab9c29909fc81712f7ade3d", null ],
    [ "set_key", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a4de741b3bbeb9f3dcb1119eed662cb85", null ],
    [ "set_upload_id", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a2eba2c0960b560fa91c573035f0bc54f", null ],
    [ "upload_id", "d4/ded/structoss__initiate__multipart__upload__result__s.html#a5755e07d2244386fcb4c521cfb09eed6", null ]
];