var structoss__copy__object__result__s =
[
    [ "etag", "d4/d4a/structoss__copy__object__result__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "d4/d4a/structoss__copy__object__result__s.html#ac055a3ba88ba1f7c528e2639d52d04e9", null ],
    [ "get_last_modified", "d4/d4a/structoss__copy__object__result__s.html#a306e2c701955b68f69b04a6f302f894a", null ],
    [ "last_modified", "d4/d4a/structoss__copy__object__result__s.html#a99d1353a783d112bf698109c33c15e7a", null ],
    [ "set_etag", "d4/d4a/structoss__copy__object__result__s.html#a2b3ef5b085df41b6490ab860f53d2721", null ],
    [ "set_last_modified", "d4/d4a/structoss__copy__object__result__s.html#a91feec3d1bc661065a250310c2d92719", null ]
];