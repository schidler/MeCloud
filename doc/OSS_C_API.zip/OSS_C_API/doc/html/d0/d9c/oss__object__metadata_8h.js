var oss__object__metadata_8h =
[
    [ "_OSS_CONSTANTS_H", "d0/d9c/oss__object__metadata_8h.html#a227c464e753487eff5856e2015ecbf11", null ],
    [ "oss_object_metadata_t", "d2/d08/group__oss__object__metadata__t.html#ga6256bf4ce253d5878a6a0952c2d14035", null ],
    [ "object_metadata_finalize", "d2/d08/group__oss__object__metadata__t.html#ga5a8e8ba70553856bc6686ced0f62923b", null ],
    [ "object_metadata_initialize", "d2/d08/group__oss__object__metadata__t.html#ga2225ebea2328d99d9e8c1fe6e2a36595", null ]
];