var oss__object__summary_8h =
[
    [ "_OSS_OWNER_H", "d0/d55/oss__object__summary_8h.html#ae2922a9975660d3be9317272b04895f3", null ],
    [ "oss_object_summary_t", "df/de1/group__oss__object__summary__t.html#ga7d763fea3e926032e43d331eff6962fa", null ],
    [ "object_summary_finalize", "df/de1/group__oss__object__summary__t.html#gae1f598e4a6a139d6bd5f7ef9c971def0", null ],
    [ "object_summary_initialize", "df/de1/group__oss__object__summary__t.html#ga57f7db45a7ee2ead05887bde3c3d8a66", null ]
];