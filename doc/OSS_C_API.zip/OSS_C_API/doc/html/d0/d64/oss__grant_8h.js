var oss__grant_8h =
[
    [ "oss_grant_t", "d0/d21/group__oss__grant__t.html#gacf2932b30291831d588e79bcc1240429", null ],
    [ "grant_finalize", "d0/d21/group__oss__grant__t.html#ga0326ce20388e15c8df860d60b8b4ee87", null ],
    [ "grant_initialize", "d0/d21/group__oss__grant__t.html#ga3599b9f9cfa46400350321e45ce17974", null ]
];