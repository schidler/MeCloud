var oss__object__group__item_8h =
[
    [ "oss_object_group_item_t", "d9/d45/group__oss__object__group__item__t.html#ga8b441f85fcb56272895d59d1d8aa3e9e", null ],
    [ "object_group_item_finalize", "d9/d45/group__oss__object__group__item__t.html#ga8d157d388cc3f4470f2df448fab012d6", null ],
    [ "object_group_item_initialize", "d9/d45/group__oss__object__group__item__t.html#ga4918e3600604a7c3eed7b11cfe993be7", null ]
];