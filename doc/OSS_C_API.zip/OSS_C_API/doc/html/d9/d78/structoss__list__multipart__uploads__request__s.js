var structoss__list__multipart__uploads__request__s =
[
    [ "bucket_name", "d9/d78/structoss__list__multipart__uploads__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "delimiter", "d9/d78/structoss__list__multipart__uploads__request__s.html#aac0782d159773b2ffc74276d33b81d3c", null ],
    [ "get_bucket_name", "d9/d78/structoss__list__multipart__uploads__request__s.html#a0d5040ddf4e188abae936fff867cac26", null ],
    [ "get_delimiter", "d9/d78/structoss__list__multipart__uploads__request__s.html#aab72694dceb8544b384d47771cb1cbfd", null ],
    [ "get_key_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#ad51fbb84e2a12946b09c48eb72edac2e", null ],
    [ "get_max_uploads", "d9/d78/structoss__list__multipart__uploads__request__s.html#a26dfd5928e8cccaab224ba3ea5a20f55", null ],
    [ "get_prefix", "d9/d78/structoss__list__multipart__uploads__request__s.html#ab743dcd38d60bc3b654eec86e9ceb95e", null ],
    [ "get_upload_id_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#a0d6c0c7750e70c58ab2f3606ee36a144", null ],
    [ "key_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#ac3935db78c081e8d5cfd4efb5e300990", null ],
    [ "max_uploads", "d9/d78/structoss__list__multipart__uploads__request__s.html#a2b1be129e11aeb43665d88e6ce9bb994", null ],
    [ "prefix", "d9/d78/structoss__list__multipart__uploads__request__s.html#ad2849cf781a4db22cc1b31eaaee50a4f", null ],
    [ "set_bucket_name", "d9/d78/structoss__list__multipart__uploads__request__s.html#a8c505ec34fd09cbbf4fea5f25687bedc", null ],
    [ "set_delimiter", "d9/d78/structoss__list__multipart__uploads__request__s.html#ab015711c745f50d7e53c8b7437fbd567", null ],
    [ "set_key_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#a16c4cd89aa9f1355488d9d2c939a1679", null ],
    [ "set_max_uploads", "d9/d78/structoss__list__multipart__uploads__request__s.html#a7037728d6a18facf79b38abdea49530b", null ],
    [ "set_prefix", "d9/d78/structoss__list__multipart__uploads__request__s.html#a71dd7b93857fe386cd1bee24a289d293", null ],
    [ "set_upload_id_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#a740e9124166eea018df1d65d71b9765c", null ],
    [ "upload_id_marker", "d9/d78/structoss__list__multipart__uploads__request__s.html#a249bdee5a20b4f71785b36df45166dc8", null ]
];