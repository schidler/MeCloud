var oss__list__multipart__uploads__request_8h =
[
    [ "oss_list_multipart_uploads_request_t", "d9/ded/group__oss__list__multipart__uploads__request__t.html#gaef4f92b98c629dad17270751d41453dc", null ],
    [ "list_multipart_uploads_request_finalize", "d9/ded/group__oss__list__multipart__uploads__request__t.html#ga756d8fe1b3bc54ac28788eeac1baad7c", null ],
    [ "list_multipart_uploads_request_initialize", "d9/ded/group__oss__list__multipart__uploads__request__t.html#ga98fa1b7323a38700f70e85bc6229b01c", null ]
];