var oss__abort__multipart__upload__request_8h =
[
    [ "oss_abort_multipart_upload_request_t", "dd/dba/group__oss__abort__multipart__upload__request__t.html#ga951a22c058b66d8aaf7d95b7084b7407", null ],
    [ "abort_multipart_upload_request_finalize", "dd/dba/group__oss__abort__multipart__upload__request__t.html#ga936ec48c42ac3de89b1dc5ec628e6aa5", null ],
    [ "abort_multipart_upload_request_initialize", "dd/dba/group__oss__abort__multipart__upload__request__t.html#ga02cc5821b70534fb2faaac07a63276a7", null ]
];