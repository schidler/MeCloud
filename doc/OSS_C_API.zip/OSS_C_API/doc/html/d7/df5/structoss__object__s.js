var structoss__object__s =
[
    [ "bucket_name", "d7/df5/structoss__object__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d7/df5/structoss__object__s.html#a2ed0859f641aede6e28f6536cdf9a3f1", null ],
    [ "get_key", "d7/df5/structoss__object__s.html#ab6040e25ca41dda07663a7dac592f153", null ],
    [ "get_object_content", "d7/df5/structoss__object__s.html#ae3db865f200aea13dea44dad97647ee8", null ],
    [ "get_object_metadata", "d7/df5/structoss__object__s.html#a2db38e58ce02a131cdd36fd896e2a155", null ],
    [ "key", "d7/df5/structoss__object__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "object_content", "d7/df5/structoss__object__s.html#a146ca8c7fb0d1d853c851fe9d60c8114", null ],
    [ "object_content_len", "d7/df5/structoss__object__s.html#a96412a448f3caf2b17cd9551d56aba34", null ],
    [ "object_metadata", "d7/df5/structoss__object__s.html#ae52e96502d05fae1bbf164d806c47142", null ],
    [ "set_bucket_name", "d7/df5/structoss__object__s.html#a60252cb33e79d4c9c58f3d1281fd6ed6", null ],
    [ "set_key", "d7/df5/structoss__object__s.html#a593cbae626491c1ace4fbe2d8c1a1e4d", null ],
    [ "set_object_content", "d7/df5/structoss__object__s.html#a2650da251194b62c456c4cbe46a89331", null ],
    [ "set_object_metadata", "d7/df5/structoss__object__s.html#a599286af7e986c9c412ab8ab115e8ebd", null ]
];