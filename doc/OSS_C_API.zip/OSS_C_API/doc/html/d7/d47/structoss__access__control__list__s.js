var structoss__access__control__list__s =
[
    [ "get_grant", "d7/d47/structoss__access__control__list__s.html#a81799937e37327ce2c795a0725eac2ea", null ],
    [ "get_owner", "d7/d47/structoss__access__control__list__s.html#a8f4f2fa7dd9f8ec85c05d6f285fe0113", null ],
    [ "grant", "d7/d47/structoss__access__control__list__s.html#a0ee0ddee74feeac0cceb8dac28b54bc1", null ],
    [ "owner", "d7/d47/structoss__access__control__list__s.html#a389504832e4d361979100f9267479b8a", null ],
    [ "set_grant", "d7/d47/structoss__access__control__list__s.html#ab44515b54822b6a48de809b0051bfbbe", null ],
    [ "set_owner", "d7/d47/structoss__access__control__list__s.html#a98e38c0852b1ae36db90bf8a71892d6c", null ]
];