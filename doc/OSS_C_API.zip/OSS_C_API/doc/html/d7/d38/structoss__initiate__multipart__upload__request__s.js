var structoss__initiate__multipart__upload__request__s =
[
    [ "bucket_name", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a8eb9cd6959ab101cb9dce72cd034527f", null ],
    [ "get_key", "d7/d38/structoss__initiate__multipart__upload__request__s.html#ae09449e076f3de9becdc001f4de654af", null ],
    [ "get_object_metadata", "d7/d38/structoss__initiate__multipart__upload__request__s.html#abb1d66b719408f833d58cad458aa5ca5", null ],
    [ "key", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "object_metadata", "d7/d38/structoss__initiate__multipart__upload__request__s.html#ae52e96502d05fae1bbf164d806c47142", null ],
    [ "set_bucket_name", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a2081d965bb45b8b6058d8c433497cfb6", null ],
    [ "set_key", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a96e8c959e5ab760bf3d9f7b4b91186a5", null ],
    [ "set_object_metadata", "d7/d38/structoss__initiate__multipart__upload__request__s.html#a0c1acdaa8850fbcee64f83c7ffccfcc6", null ]
];