var oss__part__summary_8h =
[
    [ "oss_part_summary_t", "dc/de8/group__oss__part__summary__t.html#gab3c855fa85fdaa7cd4befc864c31bd8e", null ],
    [ "part_summary_finalize", "dc/de8/group__oss__part__summary__t.html#ga12107ce74adf16377481fe8f9c084c2f", null ],
    [ "part_summary_initialize", "dc/de8/group__oss__part__summary__t.html#ga4777b8788e941213c910dd042955079e", null ]
];