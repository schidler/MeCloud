var oss__list__objects__request_8h =
[
    [ "oss_list_objects_request_t", "d6/d66/group__oss__list__objects__request__t.html#ga6483a1ad674014be88a24ab095e0f8b8", null ],
    [ "list_objects_request_finalize", "d6/d66/group__oss__list__objects__request__t.html#ga2fff98ea66abf4e9c8ca556700fbb942", null ],
    [ "list_objects_request_initialize", "d6/d66/group__oss__list__objects__request__t.html#gab26b149fc96b1e1339cfe5ecfb34914e", null ],
    [ "list_objects_request_initialize_with_args", "d6/d66/group__oss__list__objects__request__t.html#ga42596076542ba018980917c19d96b002", null ],
    [ "list_objects_request_initialize_with_bucket_name", "d6/d66/group__oss__list__objects__request__t.html#ga66d4027bd7a36b7be484fccbafbdf23e", null ]
];