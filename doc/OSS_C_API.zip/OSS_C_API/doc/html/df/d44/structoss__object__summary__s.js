var structoss__object__summary__s =
[
    [ "etag", "df/d44/structoss__object__summary__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "df/d44/structoss__object__summary__s.html#a419a4517ae82f72503d4f966cfa451b3", null ],
    [ "get_key", "df/d44/structoss__object__summary__s.html#ac43976040aada0b5cfa3d565c4cecdbf", null ],
    [ "get_last_modified", "df/d44/structoss__object__summary__s.html#a0338ae5a370936f0278c296621bd54d9", null ],
    [ "get_owner", "df/d44/structoss__object__summary__s.html#abb5dc262890b6c1d6c846e91633c1bab", null ],
    [ "get_size", "df/d44/structoss__object__summary__s.html#ac435d92ffec98130b0e02f72ad0fd400", null ],
    [ "get_storage_class", "df/d44/structoss__object__summary__s.html#a73350f3616f96cf873e7b0bcae7a52b6", null ],
    [ "get_type", "df/d44/structoss__object__summary__s.html#a7907d1f338920522d30cbf6a3370ce1a", null ],
    [ "key", "df/d44/structoss__object__summary__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "last_modified", "df/d44/structoss__object__summary__s.html#a99d1353a783d112bf698109c33c15e7a", null ],
    [ "owner", "df/d44/structoss__object__summary__s.html#a389504832e4d361979100f9267479b8a", null ],
    [ "set_etag", "df/d44/structoss__object__summary__s.html#a25b99b9d2561feb39abe3b2a311aca57", null ],
    [ "set_key", "df/d44/structoss__object__summary__s.html#a39695ce1bf713d91b3cbda3406e63f16", null ],
    [ "set_last_modified", "df/d44/structoss__object__summary__s.html#a0c0b83d5be943a3d8dc039741a0afc86", null ],
    [ "set_owner", "df/d44/structoss__object__summary__s.html#a981acd86cc61d00acbec80b87f25c718", null ],
    [ "set_size", "df/d44/structoss__object__summary__s.html#a43cba08f503e155ada85cce7e87d5b94", null ],
    [ "set_storage_class", "df/d44/structoss__object__summary__s.html#a894afa988e7a51b55fb51fe48b72faa0", null ],
    [ "set_type", "df/d44/structoss__object__summary__s.html#a161009dc78fc7c402224e91905b07c06", null ],
    [ "size", "df/d44/structoss__object__summary__s.html#a37363161b41c4165b98cba7abc7a9d95", null ],
    [ "storage_class", "df/d44/structoss__object__summary__s.html#afad849df9a7cfeba4abd9e511683a2ff", null ],
    [ "type", "df/d44/structoss__object__summary__s.html#a23506fc4821ab6d9671f3e6222591a96", null ]
];