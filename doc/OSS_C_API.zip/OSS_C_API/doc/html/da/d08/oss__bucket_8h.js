var oss__bucket_8h =
[
    [ "_OSS_OWNER_H", "da/d08/oss__bucket_8h.html#ae2922a9975660d3be9317272b04895f3", null ],
    [ "oss_bucket_t", "d1/dc0/group__oss__bucket__t.html#gace35a746803a76c62b51772ff98a9bd7", null ],
    [ "bucket_finalize", "d1/dc0/group__oss__bucket__t.html#ga0fbde89eb06ceac7562356ee395d69c1", null ],
    [ "bucket_initialize", "d1/dc0/group__oss__bucket__t.html#gadef6bc163c155c5722341f1caa081264", null ],
    [ "bucket_initialize_with_name", "d1/dc0/group__oss__bucket__t.html#ga12c8ae235dff026554a03ee3b1712fd9", null ]
];