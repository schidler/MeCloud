var oss__access__control__list_8h =
[
    [ "_OSS_GRANT_H", "da/d7a/oss__access__control__list_8h.html#ae1c91fd87cedfddb072dad0d05a3fac3", null ],
    [ "_OSS_OWNER_H", "da/d7a/oss__access__control__list_8h.html#ae2922a9975660d3be9317272b04895f3", null ],
    [ "oss_access_control_list_t", "d2/d4c/group__oss__access__control__list__t.html#gac5f0d691531316b81e162036511e5309", null ],
    [ "access_control_list_finalize", "d2/d4c/group__oss__access__control__list__t.html#ga196fe8f221ce6db310d9feb70fc471a2", null ],
    [ "access_control_list_initialize", "d2/d4c/group__oss__access__control__list__t.html#gaa5f74c9da14fe3ddeba29960dc7527b1", null ]
];