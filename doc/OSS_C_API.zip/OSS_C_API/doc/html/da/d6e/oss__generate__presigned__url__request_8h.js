var oss__generate__presigned__url__request_8h =
[
    [ "_OSS_RESPONSE_HEADER_OVERRIDES_H", "da/d6e/oss__generate__presigned__url__request_8h.html#a4a9f34efd1f78f30e27bca353e893259", null ],
    [ "oss_generate_presigned_url_request_t", "d4/d3c/group__oss__generate__presigned__url__request__t.html#ga2a3675330fb94ca5a294686371b81ad2", null ],
    [ "generate_presigned_url_request_finalize", "d4/d3c/group__oss__generate__presigned__url__request__t.html#ga2f04cda4bed52436ea73b9f5b037959a", null ],
    [ "generate_presigned_url_request_initialize", "d4/d3c/group__oss__generate__presigned__url__request__t.html#gabddaf9fb7539088e8fea80b49603a1c1", null ],
    [ "generate_presigned_url_request_initialize_with_method", "d4/d3c/group__oss__generate__presigned__url__request__t.html#ga1e82379978a72843dd6b0c72c0d90ce7", null ]
];