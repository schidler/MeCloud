var oss__owner_8h =
[
    [ "oss_owner_t", "de/db9/group__oss__owner__t.html#gad3ec196d6aca9552130e1bbf5265ba73", null ],
    [ "owner_finalize", "de/db9/group__oss__owner__t.html#ga509adfb57d3aaf2a1fd4193e25d8ca57", null ],
    [ "owner_initialize", "de/db9/group__oss__owner__t.html#ga13ee08a6ed83d1a52c0bd55838254268", null ],
    [ "owner_initialize_with_id", "de/db9/group__oss__owner__t.html#gad962836a76420309d45a757a3fcf5b7e", null ]
];