var structoss__multipart__object__group__s =
[
    [ "etag", "d1/d0d/structoss__multipart__object__group__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "d1/d0d/structoss__multipart__object__group__s.html#a93da88c978ad8cd52eafdfa55e304d0c", null ],
    [ "get_part_name", "d1/d0d/structoss__multipart__object__group__s.html#accf265fd3b1dc3b6325977bb1ec82452", null ],
    [ "get_part_number", "d1/d0d/structoss__multipart__object__group__s.html#a1332504e1f64dd96f40ab91cc55ebe90", null ],
    [ "get_part_size", "d1/d0d/structoss__multipart__object__group__s.html#aa966056819bbfb7a3d7a057b15524997", null ],
    [ "part_name", "d1/d0d/structoss__multipart__object__group__s.html#a28556c0e804ff9fa3d3e0c8f54489223", null ],
    [ "part_number", "d1/d0d/structoss__multipart__object__group__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "part_size", "d1/d0d/structoss__multipart__object__group__s.html#a8ccd6ae602f56322685e8933fae36f49", null ],
    [ "set_etag", "d1/d0d/structoss__multipart__object__group__s.html#a3dc4211d199da4044aebf9dca24999d2", null ],
    [ "set_part_name", "d1/d0d/structoss__multipart__object__group__s.html#a18bc6991bfbff0ed583fafcbda4af231", null ],
    [ "set_part_number", "d1/d0d/structoss__multipart__object__group__s.html#ae3a81c0c78739df8fda0578055450122", null ],
    [ "set_part_size", "d1/d0d/structoss__multipart__object__group__s.html#a13c300cdcffedab43150d94edbc278d3", null ]
];