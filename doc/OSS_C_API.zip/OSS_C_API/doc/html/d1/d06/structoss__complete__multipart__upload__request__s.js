var structoss__complete__multipart__upload__request__s =
[
    [ "bucket_name", "d1/d06/structoss__complete__multipart__upload__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d1/d06/structoss__complete__multipart__upload__request__s.html#aa8100bf6f68a8c9fb7cfebe62160fd53", null ],
    [ "get_key", "d1/d06/structoss__complete__multipart__upload__request__s.html#a3dc5f46379eec913c53f70901a032c6e", null ],
    [ "get_part_etags", "d1/d06/structoss__complete__multipart__upload__request__s.html#aa60150228d4015afc1b44f3dd7a3b44b", null ],
    [ "get_upload_id", "d1/d06/structoss__complete__multipart__upload__request__s.html#a1364e6194fa696811242ed1a82fa05e7", null ],
    [ "key", "d1/d06/structoss__complete__multipart__upload__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "part_etags", "d1/d06/structoss__complete__multipart__upload__request__s.html#acc6dad609ecf773a3aa435934597c5d0", null ],
    [ "part_etags_number", "d1/d06/structoss__complete__multipart__upload__request__s.html#a2fe30616f366c0d7a36d15b2d6128849", null ],
    [ "set_bucket_name", "d1/d06/structoss__complete__multipart__upload__request__s.html#a732952b8e224f9a7395bdd883adbd335", null ],
    [ "set_key", "d1/d06/structoss__complete__multipart__upload__request__s.html#ae5b16c8fbdd72eb26c10fa0bb6eba6f6", null ],
    [ "set_part_etags", "d1/d06/structoss__complete__multipart__upload__request__s.html#ac28fe2b916452bfbd3a36cc3b1b8f869", null ],
    [ "set_upload_id", "d1/d06/structoss__complete__multipart__upload__request__s.html#ad35ad8365f7025d8f57872da2bda8857", null ],
    [ "upload_id", "d1/d06/structoss__complete__multipart__upload__request__s.html#a5755e07d2244386fcb4c521cfb09eed6", null ]
];