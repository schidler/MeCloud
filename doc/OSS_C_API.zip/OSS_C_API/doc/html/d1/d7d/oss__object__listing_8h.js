var oss__object__listing_8h =
[
    [ "_OSS_OBJECT_SUMMARY_H", "d1/d7d/oss__object__listing_8h.html#a3ab21828f1741db61fd73baa775f66f2", null ],
    [ "oss_object_listing_t", "da/d78/group__oss__object__listing__t.html#gae5dfa8244d84e55938131b5816c6c18a", null ],
    [ "object_listing_finalize", "da/d78/group__oss__object__listing__t.html#ga5cd86e5fc45ef72d6c68a1e4d82e4d22", null ],
    [ "object_listing_initialize", "da/d78/group__oss__object__listing__t.html#gaa37f36e056773601fc31896b9428791b", null ]
];