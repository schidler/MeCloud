var oss__copy__object__result_8h =
[
    [ "oss_copy_object_result_t", "d2/d4f/group__oss__copy__object__result__t.html#gaeb342c550446cbd927698a20f723da50", null ],
    [ "copy_object_result_finalize", "d2/d4f/group__oss__copy__object__result__t.html#ga9088e7c890b4497b429b21cf3c15e453", null ],
    [ "copy_object_result_initialize", "d2/d4f/group__oss__copy__object__result__t.html#gaa1a12fd7ba9ba71a5c2c22316483f678", null ]
];