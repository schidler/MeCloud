var structoss__list__parts__request__s =
[
    [ "bucket_name", "d1/dca/structoss__list__parts__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d1/dca/structoss__list__parts__request__s.html#a725d57c18bd2cbbb0360619ad704acbf", null ],
    [ "get_key", "d1/dca/structoss__list__parts__request__s.html#a0c5a47f3ecd310abd8260ea9c5964e4f", null ],
    [ "get_max_parts", "d1/dca/structoss__list__parts__request__s.html#ab2fd822ba82f470dba739afae64cdf87", null ],
    [ "get_part_number_marker", "d1/dca/structoss__list__parts__request__s.html#ab4c8b6ea05b6e2cbd867f9e9a86404a4", null ],
    [ "get_upload_id", "d1/dca/structoss__list__parts__request__s.html#a63425dce989c0e19542807394e93cabd", null ],
    [ "key", "d1/dca/structoss__list__parts__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "max_parts", "d1/dca/structoss__list__parts__request__s.html#aff6042d169ad0e48fefcf54406433074", null ],
    [ "part_number_marker", "d1/dca/structoss__list__parts__request__s.html#a9bf8400b647393d9ac1acf9d3d222551", null ],
    [ "set_bucket_name", "d1/dca/structoss__list__parts__request__s.html#aa101de17c06435bee86633d271e6a2c0", null ],
    [ "set_key", "d1/dca/structoss__list__parts__request__s.html#a8b616bca0a795ce6d1fbd726bb903534", null ],
    [ "set_max_parts", "d1/dca/structoss__list__parts__request__s.html#a7276d8c051a2d0613fce868ed818be62", null ],
    [ "set_part_number_marker", "d1/dca/structoss__list__parts__request__s.html#ac8af65c8d31f0c12ee729fd4c210b377", null ],
    [ "set_upload_id", "d1/dca/structoss__list__parts__request__s.html#a90f78e2ff274fedc7c935c3fa5e1bbd9", null ],
    [ "upload_id", "d1/dca/structoss__list__parts__request__s.html#a5755e07d2244386fcb4c521cfb09eed6", null ]
];