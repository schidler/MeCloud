var structoss__post__object__group__request__s =
[
    [ "bucket_name", "d1/deb/structoss__post__object__group__request__s.html#a9c4511a2051789ad75fa5703cf45ed21", null ],
    [ "get_bucket_name", "d1/deb/structoss__post__object__group__request__s.html#ab144355905b9358e26ab16000c15b5b2", null ],
    [ "get_items", "d1/deb/structoss__post__object__group__request__s.html#a694d6d30a0d2bb90a1d54fa6b9975199", null ],
    [ "get_key", "d1/deb/structoss__post__object__group__request__s.html#a442fd812e59a7d3c5818d975f0b87b6b", null ],
    [ "itemnums", "d1/deb/structoss__post__object__group__request__s.html#a3a64f8c9a18bb477f271520df691955c", null ],
    [ "items", "d1/deb/structoss__post__object__group__request__s.html#a9c43adaf69381de297f8efd43c1f3ba6", null ],
    [ "key", "d1/deb/structoss__post__object__group__request__s.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "set_bucket_name", "d1/deb/structoss__post__object__group__request__s.html#a9e3ba890ccd63b960fd338578dce9fec", null ],
    [ "set_items", "d1/deb/structoss__post__object__group__request__s.html#a4d75155cd8934ec19fd7cec9fb21b841", null ],
    [ "set_key", "d1/deb/structoss__post__object__group__request__s.html#a8e21283450a4329ca6730abae25290a9", null ]
];