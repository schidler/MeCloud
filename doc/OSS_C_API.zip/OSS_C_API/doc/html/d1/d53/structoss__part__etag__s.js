var structoss__part__etag__s =
[
    [ "etag", "d1/d53/structoss__part__etag__s.html#ae96fbf2bcf0833cd225f57b894f35fc8", null ],
    [ "get_etag", "d1/d53/structoss__part__etag__s.html#a18464cce8036f3140a9e3c7abc31253c", null ],
    [ "get_part_number", "d1/d53/structoss__part__etag__s.html#adac23e9030df0c0f4847e3083b1abe51", null ],
    [ "part_number", "d1/d53/structoss__part__etag__s.html#acc77b0d64ed7d3bb199fba2446d2949a", null ],
    [ "set_etag", "d1/d53/structoss__part__etag__s.html#a4db10096e84d8e83ca1684ab6a539a51", null ],
    [ "set_part_number", "d1/d53/structoss__part__etag__s.html#aa2086b946821c2aa8f14b414b5175bb8", null ]
];