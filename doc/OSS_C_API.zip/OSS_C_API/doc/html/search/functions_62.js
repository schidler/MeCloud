var searchData=
[
  ['bucket_5ffinalize',['bucket_finalize',['../d1/dc0/group__oss__bucket__t.html#ga0fbde89eb06ceac7562356ee395d69c1',1,'oss_bucket.h']]],
  ['bucket_5finitialize',['bucket_initialize',['../d1/dc0/group__oss__bucket__t.html#gadef6bc163c155c5722341f1caa081264',1,'oss_bucket.h']]],
  ['bucket_5finitialize_5fwith_5fname',['bucket_initialize_with_name',['../d1/dc0/group__oss__bucket__t.html#ga12c8ae235dff026554a03ee3b1712fd9',1,'oss_bucket.h']]]
];
