var searchData=
[
  ['abort_5fmultipart_5fupload_5frequest_5ffinalize',['abort_multipart_upload_request_finalize',['../dd/dba/group__oss__abort__multipart__upload__request__t.html#ga936ec48c42ac3de89b1dc5ec628e6aa5',1,'oss_abort_multipart_upload_request.h']]],
  ['abort_5fmultipart_5fupload_5frequest_5finitialize',['abort_multipart_upload_request_initialize',['../dd/dba/group__oss__abort__multipart__upload__request__t.html#ga02cc5821b70534fb2faaac07a63276a7',1,'oss_abort_multipart_upload_request.h']]],
  ['access_5fcontrol_5flist_5ffinalize',['access_control_list_finalize',['../d2/d4c/group__oss__access__control__list__t.html#ga196fe8f221ce6db310d9feb70fc471a2',1,'oss_access_control_list.h']]],
  ['access_5fcontrol_5flist_5finitialize',['access_control_list_initialize',['../d2/d4c/group__oss__access__control__list__t.html#gaa5f74c9da14fe3ddeba29960dc7527b1',1,'oss_access_control_list.h']]]
];
