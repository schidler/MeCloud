var searchData=
[
  ['abort_5fmultipart_5fupload_5frequest_5ffinalize',['abort_multipart_upload_request_finalize',['../dd/dba/group__oss__abort__multipart__upload__request__t.html#ga936ec48c42ac3de89b1dc5ec628e6aa5',1,'oss_abort_multipart_upload_request.h']]],
  ['abort_5fmultipart_5fupload_5frequest_5finitialize',['abort_multipart_upload_request_initialize',['../dd/dba/group__oss__abort__multipart__upload__request__t.html#ga02cc5821b70534fb2faaac07a63276a7',1,'oss_abort_multipart_upload_request.h']]],
  ['access_5fcontrol_5flist_5ffinalize',['access_control_list_finalize',['../d2/d4c/group__oss__access__control__list__t.html#ga196fe8f221ce6db310d9feb70fc471a2',1,'oss_access_control_list.h']]],
  ['access_5fcontrol_5flist_5finitialize',['access_control_list_initialize',['../d2/d4c/group__oss__access__control__list__t.html#gaa5f74c9da14fe3ddeba29960dc7527b1',1,'oss_access_control_list.h']]],
  ['access_5fid',['access_id',['../de/da5/structoss__client__s.html#a33c6d88cd03f42ab258dc2da344409b2',1,'oss_client_s']]],
  ['access_5fkey',['access_key',['../de/da5/structoss__client__s.html#ad6f7717505e9a68b5f55d3bed7105898',1,'oss_client_s']]],
  ['add_5fdefault_5fmetadata',['add_default_metadata',['../d5/d38/structoss__object__metadata__s.html#adf9e46ac210c2857935347a0fb633db0',1,'oss_object_metadata_s']]],
  ['add_5fuser_5fmetadata',['add_user_metadata',['../db/dcc/structoss__generate__presigned__url__request__s.html#aa52f1f23dba5d70a534f586a886db167',1,'oss_generate_presigned_url_request_s::add_user_metadata()'],['../d5/d38/structoss__object__metadata__s.html#a1dfc8cab52c863caddec61a719002a49',1,'oss_object_metadata_s::add_user_metadata()']]],
  ['allocated',['allocated',['../d6/d3a/structparam__buffer__s.html#a44ac4c6a3693f3d2fa34a50428e42237',1,'param_buffer_s']]]
];
