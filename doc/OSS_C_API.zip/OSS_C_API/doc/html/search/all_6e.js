var searchData=
[
  ['name',['name',['../db/db9/structoss__bucket__s.html#a5ac083a645d964373f022d03df4849c8',1,'oss_bucket_s']]],
  ['next',['next',['../db/d19/structoss__grant__s.html#a59aafbccab53b49e8f1f99f0eb8ff0a1',1,'oss_grant_s']]],
  ['next_5fkey_5fmarker',['next_key_marker',['../d5/d60/structoss__multipart__upload__listing__s.html#adc3e84c5bb3af9da8c363f21cb30f059',1,'oss_multipart_upload_listing_s']]],
  ['next_5fmarker',['next_marker',['../d8/d42/structoss__object__listing__s.html#a77302ae8ca02ef6fca6f39dfc961a061',1,'oss_object_listing_s']]],
  ['next_5fpart_5fnumber_5fmarker',['next_part_number_marker',['../db/d7d/structoss__part__listing__s.html#a9127ad97fbb190f19572ba2abbe8a9c9',1,'oss_part_listing_s']]],
  ['next_5fupload_5fid_5fmarker',['next_upload_id_marker',['../d5/d60/structoss__multipart__upload__listing__s.html#a6d9fee711a4c2c7dc96319617d60f211',1,'oss_multipart_upload_listing_s']]],
  ['no_5fmatching_5fetag_5fconstraints',['no_matching_etag_constraints',['../da/dfb/structoss__copy__object__request__s.html#a98bac95dc648f0e6f6977466d85cad34',1,'oss_copy_object_request_s::no_matching_etag_constraints()'],['../de/d4e/structoss__get__object__group__request__s.html#a98bac95dc648f0e6f6977466d85cad34',1,'oss_get_object_group_request_s::no_matching_etag_constraints()'],['../dc/d2c/structoss__get__object__request__s.html#a98bac95dc648f0e6f6977466d85cad34',1,'oss_get_object_request_s::no_matching_etag_constraints()']]]
];
