var searchData=
[
  ['delete_5fmultiple_5fobject_5frequest_5ffinalize',['delete_multiple_object_request_finalize',['../d3/d7a/group__oss__delete__multiple__object__request__t.html#ga0f40dbcb23f52e7c6f29457fdd005d35',1,'oss_delete_multiple_object_request.h']]],
  ['delete_5fmultiple_5fobject_5frequest_5finitialize',['delete_multiple_object_request_initialize',['../d3/d7a/group__oss__delete__multiple__object__request__t.html#gaf8c4e3b6fca951c65f5dc608740fbdcc',1,'oss_delete_multiple_object_request.h']]]
];
