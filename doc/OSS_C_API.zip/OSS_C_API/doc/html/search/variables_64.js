var searchData=
[
  ['delimiter',['delimiter',['../d9/d78/structoss__list__multipart__uploads__request__s.html#aac0782d159773b2ffc74276d33b81d3c',1,'oss_list_multipart_uploads_request_s::delimiter()'],['../de/d9a/structoss__list__objects__request__s.html#aac0782d159773b2ffc74276d33b81d3c',1,'oss_list_objects_request_s::delimiter()'],['../d5/d60/structoss__multipart__upload__listing__s.html#aac0782d159773b2ffc74276d33b81d3c',1,'oss_multipart_upload_listing_s::delimiter()'],['../d8/d42/structoss__object__listing__s.html#aac0782d159773b2ffc74276d33b81d3c',1,'oss_object_listing_s::delimiter()']]],
  ['destination_5fbucket_5fname',['destination_bucket_name',['../da/dfb/structoss__copy__object__request__s.html#a899dcfbd498016512b5bd07e8e76431a',1,'oss_copy_object_request_s']]],
  ['destination_5fkey',['destination_key',['../da/dfb/structoss__copy__object__request__s.html#aff12ab3e57bc15a9a45b0858c637016f',1,'oss_copy_object_request_s']]],
  ['display_5fname',['display_name',['../d2/de4/structoss__owner__s.html#a4b3dc854913a2dc6d39a8f54f82a01da',1,'oss_owner_s']]]
];
