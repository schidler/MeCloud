var searchData=
[
  ['object_5fcontent',['object_content',['../d7/df5/structoss__object__s.html#a146ca8c7fb0d1d853c851fe9d60c8114',1,'oss_object_s']]],
  ['object_5fcontent_5flen',['object_content_len',['../d7/df5/structoss__object__s.html#a96412a448f3caf2b17cd9551d56aba34',1,'oss_object_s']]],
  ['object_5fmetadata',['object_metadata',['../da/dfb/structoss__copy__object__request__s.html#ae52e96502d05fae1bbf164d806c47142',1,'oss_copy_object_request_s::object_metadata()'],['../d7/d38/structoss__initiate__multipart__upload__request__s.html#ae52e96502d05fae1bbf164d806c47142',1,'oss_initiate_multipart_upload_request_s::object_metadata()'],['../d7/df5/structoss__object__s.html#ae52e96502d05fae1bbf164d806c47142',1,'oss_object_s::object_metadata()']]],
  ['owner',['owner',['../d7/d47/structoss__access__control__list__s.html#a389504832e4d361979100f9267479b8a',1,'oss_access_control_list_s::owner()'],['../db/db9/structoss__bucket__s.html#a389504832e4d361979100f9267479b8a',1,'oss_bucket_s::owner()'],['../df/d44/structoss__object__summary__s.html#a389504832e4d361979100f9267479b8a',1,'oss_object_summary_s::owner()'],['../db/d7d/structoss__part__listing__s.html#a389504832e4d361979100f9267479b8a',1,'oss_part_listing_s::owner()']]]
];
