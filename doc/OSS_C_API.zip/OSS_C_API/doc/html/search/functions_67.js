var searchData=
[
  ['generate_5fpresigned_5furl_5frequest_5ffinalize',['generate_presigned_url_request_finalize',['../d4/d3c/group__oss__generate__presigned__url__request__t.html#ga2f04cda4bed52436ea73b9f5b037959a',1,'oss_generate_presigned_url_request.h']]],
  ['generate_5fpresigned_5furl_5frequest_5finitialize',['generate_presigned_url_request_initialize',['../d4/d3c/group__oss__generate__presigned__url__request__t.html#gabddaf9fb7539088e8fea80b49603a1c1',1,'oss_generate_presigned_url_request.h']]],
  ['generate_5fpresigned_5furl_5frequest_5finitialize_5fwith_5fmethod',['generate_presigned_url_request_initialize_with_method',['../d4/d3c/group__oss__generate__presigned__url__request__t.html#ga1e82379978a72843dd6b0c72c0d90ce7',1,'oss_generate_presigned_url_request.h']]],
  ['get_5fobject_5fgroup_5findex_5fresult_5ffinalize',['get_object_group_index_result_finalize',['../db/dce/group__oss__get__object__group__index__result__t.html#gaa6a302b3456024afcf63384c9bd10d12',1,'oss_get_object_group_index_result.h']]],
  ['get_5fobject_5fgroup_5findex_5fresult_5finitialize',['get_object_group_index_result_initialize',['../db/dce/group__oss__get__object__group__index__result__t.html#ga8ee634c5cf9a56891ca65718b12463bf',1,'oss_get_object_group_index_result.h']]],
  ['get_5fobject_5fgroup_5frequest_5ffinalize',['get_object_group_request_finalize',['../d8/d13/group__oss__get__object__group__request__t.html#gae85d93447cb99de9ba4147030272398a',1,'oss_get_object_group_request.h']]],
  ['get_5fobject_5fgroup_5frequest_5finitialize',['get_object_group_request_initialize',['../d8/d13/group__oss__get__object__group__request__t.html#ga0d7355f383f49573d06303d102851b2e',1,'oss_get_object_group_request.h']]],
  ['get_5fobject_5frequest_5ffinalize',['get_object_request_finalize',['../d7/d44/group__oss__get__object__request__t.html#ga5d1a80bcdc67e99d1d5d3fc6ba1a52c2',1,'oss_get_object_request.h']]],
  ['get_5fobject_5frequest_5finitialize',['get_object_request_initialize',['../d7/d44/group__oss__get__object__request__t.html#ga66ff828c66917415730ec9e955574f61',1,'oss_get_object_request.h']]],
  ['grant_5ffinalize',['grant_finalize',['../d0/d21/group__oss__grant__t.html#ga0326ce20388e15c8df860d60b8b4ee87',1,'oss_grant.h']]],
  ['grant_5finitialize',['grant_initialize',['../d0/d21/group__oss__grant__t.html#ga3599b9f9cfa46400350321e45ce17974',1,'oss_grant.h']]]
];
