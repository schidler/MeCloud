var searchData=
[
  ['id',['id',['../d2/de4/structoss__owner__s.html#aecb3b0d045ada529257a2fbf8f829599',1,'oss_owner_s']]],
  ['identifier',['identifier',['../db/d19/structoss__grant__s.html#af5351a0143adaf16c64b881aee01d893',1,'oss_grant_s']]],
  ['initiate_5fmultipart_5fupload_5frequest_5ffinalize',['initiate_multipart_upload_request_finalize',['../db/dd9/group__oss__initiate__multipart__upload__request__t.html#gaea9fe122f01955eefdbb428cf316435c',1,'oss_initiate_multipart_upload_request.h']]],
  ['initiate_5fmultipart_5fupload_5frequest_5finitialize',['initiate_multipart_upload_request_initialize',['../db/dd9/group__oss__initiate__multipart__upload__request__t.html#gaf10fdb2081ea115ad10dc82fce73a8ec',1,'oss_initiate_multipart_upload_request.h']]],
  ['initiate_5fmultipart_5fupload_5frequest_5finitialize_5fwith_5fmetadata',['initiate_multipart_upload_request_initialize_with_metadata',['../db/dd9/group__oss__initiate__multipart__upload__request__t.html#gae21dd6a0e7e923a74e7c34cf916df22d',1,'oss_initiate_multipart_upload_request.h']]],
  ['initiate_5fmultipart_5fupload_5fresult_5ffinalize',['initiate_multipart_upload_result_finalize',['../d7/d86/group__oss__initiate__multipart__upload__result__t.html#ga5af07fb294b45f6a9dba50b887177578',1,'oss_initiate_multipart_upload_result.h']]],
  ['initiate_5fmultipart_5fupload_5fresult_5finitialize',['initiate_multipart_upload_result_initialize',['../d7/d86/group__oss__initiate__multipart__upload__result__t.html#ga3f03807444a495d587a95c8c457efabd',1,'oss_initiate_multipart_upload_result.h']]],
  ['initiated',['initiated',['../de/dc5/structoss__multipart__upload__s.html#a4f335d47ef922588400ccc852320f935',1,'oss_multipart_upload_s']]],
  ['initiator',['initiator',['../db/d7d/structoss__part__listing__s.html#a23c7fa46f3639d37c30e0318269bbd1a',1,'oss_part_listing_s']]],
  ['input_5fstream',['input_stream',['../d1/d04/structoss__upload__part__request__s.html#ac9cdca21b0de6315bf75cb294536a394',1,'oss_upload_part_request_s']]],
  ['input_5fstream_5flen',['input_stream_len',['../d1/d04/structoss__upload__part__request__s.html#ab00ad7ba59c56b6f456ad1dafad41a06',1,'oss_upload_part_request_s']]],
  ['is_5ftruncated',['is_truncated',['../d5/d60/structoss__multipart__upload__listing__s.html#a1e674fc6a14ee6045f40f62aa480b27a',1,'oss_multipart_upload_listing_s::is_truncated()'],['../d8/d42/structoss__object__listing__s.html#a1e674fc6a14ee6045f40f62aa480b27a',1,'oss_object_listing_s::is_truncated()'],['../db/d7d/structoss__part__listing__s.html#a1e674fc6a14ee6045f40f62aa480b27a',1,'oss_part_listing_s::is_truncated()']]],
  ['itemnums',['itemnums',['../d1/deb/structoss__post__object__group__request__s.html#a3a64f8c9a18bb477f271520df691955c',1,'oss_post_object_group_request_s']]],
  ['items',['items',['../d1/deb/structoss__post__object__group__request__s.html#a9c43adaf69381de297f8efd43c1f3ba6',1,'oss_post_object_group_request_s']]]
];
