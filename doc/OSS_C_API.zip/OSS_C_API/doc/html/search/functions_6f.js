var searchData=
[
  ['object_5ffinalize',['object_finalize',['../d2/d21/group__oss__object__t.html#ga208c79adaeceb63853c381aa241ecfa9',1,'oss_object.h']]],
  ['object_5fgroup_5fitem_5ffinalize',['object_group_item_finalize',['../d9/d45/group__oss__object__group__item__t.html#ga8d157d388cc3f4470f2df448fab012d6',1,'oss_object_group_item.h']]],
  ['object_5fgroup_5fitem_5finitialize',['object_group_item_initialize',['../d9/d45/group__oss__object__group__item__t.html#ga4918e3600604a7c3eed7b11cfe993be7',1,'oss_object_group_item.h']]],
  ['object_5finitialize',['object_initialize',['../d2/d21/group__oss__object__t.html#ga67675080f4651b2ce6481432fecba192',1,'oss_object.h']]],
  ['object_5flisting_5ffinalize',['object_listing_finalize',['../da/d78/group__oss__object__listing__t.html#ga5cd86e5fc45ef72d6c68a1e4d82e4d22',1,'oss_object_listing.h']]],
  ['object_5flisting_5finitialize',['object_listing_initialize',['../da/d78/group__oss__object__listing__t.html#gaa37f36e056773601fc31896b9428791b',1,'oss_object_listing.h']]],
  ['object_5fmetadata_5ffinalize',['object_metadata_finalize',['../d2/d08/group__oss__object__metadata__t.html#ga5a8e8ba70553856bc6686ced0f62923b',1,'oss_object_metadata.h']]],
  ['object_5fmetadata_5finitialize',['object_metadata_initialize',['../d2/d08/group__oss__object__metadata__t.html#ga2225ebea2328d99d9e8c1fe6e2a36595',1,'oss_object_metadata.h']]],
  ['object_5fsummary_5ffinalize',['object_summary_finalize',['../df/de1/group__oss__object__summary__t.html#gae1f598e4a6a139d6bd5f7ef9c971def0',1,'oss_object_summary.h']]],
  ['object_5fsummary_5finitialize',['object_summary_initialize',['../df/de1/group__oss__object__summary__t.html#ga57f7db45a7ee2ead05887bde3c3d8a66',1,'oss_object_summary.h']]],
  ['owner_5ffinalize',['owner_finalize',['../de/db9/group__oss__owner__t.html#ga509adfb57d3aaf2a1fd4193e25d8ca57',1,'oss_owner.h']]],
  ['owner_5finitialize',['owner_initialize',['../de/db9/group__oss__owner__t.html#ga13ee08a6ed83d1a52c0bd55838254268',1,'oss_owner.h']]],
  ['owner_5finitialize_5fwith_5fid',['owner_initialize_with_id',['../de/db9/group__oss__owner__t.html#gad962836a76420309d45a757a3fcf5b7e',1,'oss_owner.h']]]
];
