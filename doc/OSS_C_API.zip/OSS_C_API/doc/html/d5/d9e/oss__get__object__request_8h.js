var oss__get__object__request_8h =
[
    [ "_OSS_RESPONSE_HEADER_OVERRIDES_H", "d5/d9e/oss__get__object__request_8h.html#a4a9f34efd1f78f30e27bca353e893259", null ],
    [ "oss_get_object_request_t", "d7/d44/group__oss__get__object__request__t.html#ga63e07d92418bca7592e8f93236ce68f2", null ],
    [ "get_object_request_finalize", "d7/d44/group__oss__get__object__request__t.html#ga5d1a80bcdc67e99d1d5d3fc6ba1a52c2", null ],
    [ "get_object_request_initialize", "d7/d44/group__oss__get__object__request__t.html#ga66ff828c66917415730ec9e955574f61", null ]
];