var oss__list__parts__request_8h =
[
    [ "oss_list_parts_request_t", "df/d2a/group__oss__list__parts__request__t.html#ga9ec32550180f671c7fe2af5acad68249", null ],
    [ "list_parts_request_finalize", "df/d2a/group__oss__list__parts__request__t.html#ga6a383cfd1d43df600410ba3d8475ee45", null ],
    [ "list_parts_request_initialize", "df/d2a/group__oss__list__parts__request__t.html#ga109635eb2d46759b0f6fa58b4362e3fd", null ]
];