var oss__post__object__group__request_8h =
[
    [ "_OSS_OBJECT_GROUP_ITEM_H", "d5/d27/oss__post__object__group__request_8h.html#a695863b76901e30c6d9801dac37302f0", null ],
    [ "oss_post_object_group_request_t", "d9/de6/group__oss__post__object__group__request__t.html#ga70a458f413d39df43e7a8bac42221bc2", null ],
    [ "post_object_group_request_finalize", "d9/de6/group__oss__post__object__group__request__t.html#gab43a4229cc5470de0e103251addaaa18", null ],
    [ "post_object_group_request_initialize", "d9/de6/group__oss__post__object__group__request__t.html#gae9ea99e7480dd0a8068314f9077e8abc", null ]
];