var oss__get__object__group__index__result_8h =
[
    [ "_OSS_MULTIPART_OBJECT_GROUP_H", "d5/d6c/oss__get__object__group__index__result_8h.html#a9d8f01ea6e291a864649c6bdbca48f1c", null ],
    [ "oss_get_object_group_index_result_t", "db/dce/group__oss__get__object__group__index__result__t.html#gab12164b84f504d75d7a87fb5f95c5d19", null ],
    [ "get_object_group_index_result_finalize", "db/dce/group__oss__get__object__group__index__result__t.html#gaa6a302b3456024afcf63384c9bd10d12", null ],
    [ "get_object_group_index_result_initialize", "db/dce/group__oss__get__object__group__index__result__t.html#ga8ee634c5cf9a56891ca65718b12463bf", null ]
];