var oss__put__object__result_8h =
[
    [ "oss_put_object_result_t", "da/d1b/group__oss__put__object__result__t.html#gaf86e66ca429b5601749ac1fc769f0a75", null ],
    [ "put_object_result_finalize", "da/d1b/group__oss__put__object__result__t.html#gabc6da23a823ad6d7389016a9128618b5", null ],
    [ "put_object_result_initialize", "da/d1b/group__oss__put__object__result__t.html#gaf51e02ad6594de20c9b353f5ae862411", null ]
];