package eriji.com.oauth;

public class OAuthStoreException extends Exception {

    private static final long serialVersionUID = 4992264254302475287L;

    public OAuthStoreException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public OAuthStoreException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public OAuthStoreException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public OAuthStoreException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
