package eriji.com.oauth;

public class OAuthClientException extends Exception {

    private static final long serialVersionUID = 4992264254302475287L;

    public OAuthClientException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public OAuthClientException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public OAuthClientException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public OAuthClientException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
