package com.ch_linghu.fanfoudroid.dao;

public class DAOException extends Exception {
	private static final long serialVersionUID = -6901538163576215658L;

	public DAOException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DAOException(String detailMessage, Throwable throwable) {
		super(detailMessage, throwable);
		// TODO Auto-generated constructor stub
	}

	public DAOException(String detailMessage) {
		super(detailMessage);
		// TODO Auto-generated constructor stub
	}

	public DAOException(Throwable throwable) {
		super(throwable);
		// TODO Auto-generated constructor stub
	}

}
