package com.ch_linghu.fanfoudroid.task;

public enum TaskResult {
	OK, FAILED, CANCELLED,

	NOT_FOLLOWED_ERROR, IO_ERROR, AUTH_ERROR
}