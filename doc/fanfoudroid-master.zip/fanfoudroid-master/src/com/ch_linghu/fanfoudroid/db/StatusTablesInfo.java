package com.ch_linghu.fanfoudroid.db;

/**
 * All information of status table
 * 
 */
public final class StatusTablesInfo {

}