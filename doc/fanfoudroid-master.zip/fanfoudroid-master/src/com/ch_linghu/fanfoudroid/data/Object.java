package com.ch_linghu.fanfoudroid.data;

import com.ch_linghu.fanfoudroid.fanfou.WeiboResponse;
import com.ch_linghu.fanfoudroid.http.Response;

public class Object<T> extends WeiboResponse implements java.io.Serializable {

	public Object(Response res) {
		// TODO Auto-generated constructor stub
	}

	public Object(String str) {
		// TODO Auto-generated constructor stub
	}

	public Object() {
		super();
		// TODO Auto-generated constructor stub
	}

}
