package com.ch_linghu.fanfoudroid.ui.base;

public interface Refreshable {
	void doRetrieve();
}
