package com.ch_linghu.fanfoudroid.ui.module;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

public class RefreshableListView extends ListView {

	public RefreshableListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

}
